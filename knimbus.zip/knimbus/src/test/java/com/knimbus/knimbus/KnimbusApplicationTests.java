package com.knimbus.knimbus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnimbusApplicationTests {

	@Test
	void contextLoads() {
	}

}
