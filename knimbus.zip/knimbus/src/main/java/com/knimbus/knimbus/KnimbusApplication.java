package com.knimbus.knimbus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class KnimbusApplication {
	public static void main(String[] args) {

		SpringApplication.run(KnimbusApplication .class,args);

	}

}

